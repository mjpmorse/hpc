each question is contained in a folder with the source code and a shell file to make the code. 

I have also included the contents of my /run directory on the ccr

To compile a code run the sh script. With the exception of the time for 3 all data files are produced in the /run directory.

the times were put together by hand into a single file.

the report is in report directory
